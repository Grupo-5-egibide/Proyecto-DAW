
package Modelo.UML;

import java.util.ArrayList;
import java.util.Date;

public class Vehiculo {
    private int idVehiculo;
    private String matricula;
    private String marca;
    private String modelo;
    private String kilometraje;
    private Date anyo;
    
    //relaciones
    private ArrayList<Parte> listaPartes;

    public Vehiculo() {
    }

    public Vehiculo(int idVehiculo, String matricula, String marca, String modelo, String kilometraje, Date anyo) {
        this.idVehiculo = idVehiculo;
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometraje = kilometraje;
        this.anyo = anyo;
    }

    public Vehiculo(String matricula) {
        this.matricula = matricula;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(String kilometraje) {
        this.kilometraje = kilometraje;
    }

    public Date getAnyo() {
        return anyo;
    }

    public void setAnyo(Date anyo) {
        this.anyo = anyo;
    }

    public ArrayList<Parte> getListaPartes() {
        return listaPartes;
    }

    public void setListaPartes(ArrayList<Parte> listaPartes) {
        this.listaPartes = listaPartes;
    }

    
}
