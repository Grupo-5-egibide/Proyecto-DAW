
package Modelo.UML;

public class Aviso {
    private String descripcion;
    private String solucionado;
    
    //relaciones
    private Trabajador listaTrabajadores;
    
    public Aviso() {
    }

    public Aviso(String descripcion, String solucionado) {
        this.descripcion = descripcion;
        this.solucionado = solucionado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getSolucionado() {
        return solucionado;
    }

    public void setSolucionado(String solucionado) {
        this.solucionado = solucionado;
    }

    public Trabajador getListaTrabajadores() {
        return listaTrabajadores;
    }

    public void setListaTrabajadores(Trabajador listaTrabajadores) {
        this.listaTrabajadores = listaTrabajadores;
    }

   
}
