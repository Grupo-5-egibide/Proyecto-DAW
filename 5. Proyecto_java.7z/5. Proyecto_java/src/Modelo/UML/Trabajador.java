
package Modelo.UML;

import java.util.ArrayList;

public class Trabajador {
    private int idTrabajador;
    private String dni;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String direccion;
    private String telefonoPers;
    private String telefonoEmp;
    private String salario;
    private String fechaNacimiento;
    private String categoria;
    
    //relaciones
    private Acceso acceso;
    private Centro centro;
    private ArrayList<Parte>listaPartes;
    private Aviso listaAvisos;

    public Trabajador() {
    }

    public Trabajador(String dni, String nombre, String apellido1, String apellido2, String direccion, String telefonoPers, String telefonoEmp, String salario, String fechaNacimiento, String categoria, Acceso acceso, Centro centro) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.direccion = direccion;
        this.telefonoPers = telefonoPers;
        this.telefonoEmp = telefonoEmp;
        this.salario = salario;
        this.fechaNacimiento = fechaNacimiento;
        this.categoria = categoria;
        this.acceso = acceso;
        this.centro = centro;
    }

    public Trabajador(String dni) {
        this.dni = dni;
    }

    public Trabajador(int idTrabajador, String dni, String nombre, String apellido1, String apellido2, String direccion, String telefonoPers, String telefonoEmp, String salario, String fechaNacimiento, String categoria) {
        this.idTrabajador = idTrabajador;
        this.dni = dni;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.direccion = direccion;
        this.telefonoPers = telefonoPers;
        this.telefonoEmp = telefonoEmp;
        this.salario = salario;
        this.fechaNacimiento = fechaNacimiento;
        this.categoria = categoria;
    }

    public int getIdTrabajador() {
        return idTrabajador;
    }

    public void setIdTrabajador(int idTrabajador) {
        this.idTrabajador = idTrabajador;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefonoPers() {
        return telefonoPers;
    }

    public void setTelefonoPers(String telefonoPers) {
        this.telefonoPers = telefonoPers;
    }

    public String getTelefonoEmp() {
        return telefonoEmp;
    }

    public void setTelefonoEmp(String telefonoEmp) {
        this.telefonoEmp = telefonoEmp;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Acceso getAcceso() {
        return acceso;
    }

    public void setAcceso(Acceso acceso) {
        this.acceso = acceso;
    }

    public Centro getCentro() {
        return centro;
    }

    public void setCentro(Centro centro) {
        this.centro = centro;
    }

    public ArrayList<Parte> getListaPartes() {
        return listaPartes;
    }

    public void setListaPartes(ArrayList<Parte> listaPartes) {
        this.listaPartes = listaPartes;
    }

    public Aviso getListaAvisos() {
        return listaAvisos;
    }

    public void setListaAvisos(Aviso listaAvisos) {
        this.listaAvisos = listaAvisos;
    }
    
    
}
