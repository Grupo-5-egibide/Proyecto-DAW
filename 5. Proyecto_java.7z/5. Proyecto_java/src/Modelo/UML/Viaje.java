
package Modelo.UML;

import java.util.Date;

public class Viaje {
    //cambiar por date!
    private String horaInicio;
    private String horaFin;
    private String albaran;
    
    //relaciones
    private Parte parte;

    public Viaje() {
    }

    public Viaje(String horaInicio, String horaFin, String albaran) {
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.albaran = albaran;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getAlbaran() {
        return albaran;
    }

    public void setAlbaran(String albaran) {
        this.albaran = albaran;
    }

    public Parte getParte() {
        return parte;
    }

    public void setParte(Parte parte) {
        this.parte = parte;
    }

    
}
