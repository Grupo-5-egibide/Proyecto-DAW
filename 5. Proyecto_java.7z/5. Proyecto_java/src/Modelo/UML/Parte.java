
package Modelo.UML;

import java.util.ArrayList;

public class Parte {
    private Integer idParte;
    private Integer kmInicio;
    private Integer kmFin;
    private Double gasto;
    private String incidencia;
    private String estado;
    
    //relaciones
    private Vehiculo vehiculo;
    private Trabajador trabajador;
    private ArrayList<Viaje>listaViajes;

    public Parte() {
    }

    public Parte(Integer idParte, Integer kmInicio, Integer kmFin, Double gasto, String incidencia, String estado) {
        this.idParte = idParte;
        this.kmInicio = kmInicio;
        this.kmFin = kmFin;
        this.gasto = gasto;
        this.incidencia = incidencia;
        this.estado = estado;
    }

    public Integer getIdParte() {
        return idParte;
    }

    public void setIdParte(Integer idParte) {
        this.idParte = idParte;
    }

    public Integer getKmInicio() {
        return kmInicio;
    }

    public void setKmInicio(Integer kmInicio) {
        this.kmInicio = kmInicio;
    }

    public Integer getKmFin() {
        return kmFin;
    }

    public void setKmFin(Integer kmFin) {
        this.kmFin = kmFin;
    }

    public Double getGasto() {
        return gasto;
    }

    public void setGasto(Double gasto) {
        this.gasto = gasto;
    }

    public String getIncidencia() {
        return incidencia;
    }

    public void setIncidencia(String incidencia) {
        this.incidencia = incidencia;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Trabajador getTrabajador() {
        return trabajador;
    }

    public void setTrabajador(Trabajador trabajador) {
        this.trabajador = trabajador;
    }

    public ArrayList<Viaje> getListaViajes() {
        return listaViajes;
    }

    public void setListaViajes(ArrayList<Viaje> listaViajes) {
        this.listaViajes = listaViajes;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("id: " + getIdParte());
        sb.append("\n");
        sb.append("Km fin: " + getKmInicio());
        sb.append("\n");
        sb.append("Km fin: " + getKmFin()); 
        sb.append("\n");
        sb.append("Gasto: " + getGasto());
        sb.append("\n");
        sb.append("Incidencia: " + getIncidencia());
        sb.append("\n");
        sb.append("Estado: " + getEstado());
        sb.append("\n\n------------------------------------------------");
        return sb.toString();     
}

}
