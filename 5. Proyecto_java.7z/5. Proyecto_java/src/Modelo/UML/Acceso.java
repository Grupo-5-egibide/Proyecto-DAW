
package Modelo.UML;

public class Acceso {
    private int idAcceso;
    private String usuario;
    private String pass;
    
    //relaciones
    private Trabajador trabajador;

    public Acceso() {
    }

    public Acceso(int id, String usuario, String pass) {
        this.idAcceso = id;
        this.usuario = usuario;
        this.pass = pass;
    }

    public Acceso(String usuario, String pass) {
        this.usuario = usuario;
        this.pass = pass;
    }

    public int getIdAcceso() {
        return idAcceso;
    }

    public void setIdAcceso(int idAcceso) {
        this.idAcceso = idAcceso;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    
}
