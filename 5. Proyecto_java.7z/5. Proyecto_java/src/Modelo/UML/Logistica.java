package Modelo.UML;

public class Logistica extends Trabajador{

    public Logistica() {
    }

    public Logistica(String dni, String nombre, String apellido1, String apellido2, String direccion, String telefonoPers, String telefonoEmp, String salario, String fechaNacimiento, String categoria, Acceso acceso, Centro centro) {
        super(dni, nombre, apellido1, apellido2, direccion, telefonoPers, telefonoEmp, salario, fechaNacimiento, categoria, acceso, centro);
    }
    
}
