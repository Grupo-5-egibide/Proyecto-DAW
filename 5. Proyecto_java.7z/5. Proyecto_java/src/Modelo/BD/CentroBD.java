
package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CentroBD {
    private static PreparedStatement sentenciaCon;
    private static String plantilla;
    private static Statement sentencia;
    private static ResultSet resultado;
    
    private static Centro centro;
    
    public static void Alta(Centro c) throws Exception{
            ConexionBD.conectarBD();
            plantilla = "INSERT INTO centro (nombre,calle,numero,cp,ciudad,provincia,tlf) VALUES (?,?,?,?,?,?,?)";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,c.getNombre());
            sentenciaCon.setString(2,c.getCalle());
            sentenciaCon.setString(3,c.getNumero());
            sentenciaCon.setString(4,c.getCp());
            sentenciaCon.setString(5,c.getCiudad());
            sentenciaCon.setString(6,c.getProvincia());
            sentenciaCon.setString(7,c.getTlf());
            
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion();
    }
    public static void Baja(Centro c) throws Exception{
            ConexionBD.conectarBD();
            plantilla = "DELETE FROM `centro` WHERE nombre = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,c.getNombre());
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion();
    }
    public static void Modificar(Centro c) throws Exception{
            ConexionBD.conectarBD();
            plantilla = "UPDATE CENTRO set calle = ?,numero = ?,cp = ?,ciudad = ?,provincia = ?,tlf= ? where nombre = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            
            sentenciaCon.setString(1,c.getCalle());
            sentenciaCon.setString(2,c.getNumero());
            sentenciaCon.setString(3,c.getCp());
            sentenciaCon.setString(4,c.getCiudad());
            sentenciaCon.setString(5,c.getProvincia());
            sentenciaCon.setString(6,c.getTlf());
            sentenciaCon.setString(7,c.getNombre());
            sentenciaCon.executeUpdate();
           
            ConexionBD.finalizarConexion();
    }
    public static Centro busquedaPorNombre(Centro c) throws Exception{
            ConexionBD.conectarBD();
            
            plantilla = "select * from centro where nombre = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,c.getNombre());
            resultado = sentenciaCon.executeQuery();
            if (resultado.next())
            {
                centro = new Centro();
                centro.setNombre(resultado.getString("nombre"));
                centro.setCalle(resultado.getString("calle"));
                centro.setNumero(resultado.getString("numero"));
                centro.setCp(resultado.getString("cp"));
                centro.setCiudad(resultado.getString("ciudad"));
                centro.setProvincia(resultado.getString("provincia"));
                centro.setTlf(resultado.getString("Tlf"));
            }
            else
                centro =  null;
            
            resultado.close();
            ConexionBD.finalizarConexion();
            return centro;
    }
    public static ArrayList<Centro> obtenerCentros() throws Exception{
  
        ArrayList<Centro> listaCentros = new ArrayList();
            
        ConexionBD.conectarBD();
        plantilla = "select * from centro";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        resultado = sentenciaCon.executeQuery();
          while (resultado.next())
          {
                centro = new Centro();
                centro.setIdCentro(resultado.getInt("idCentro"));
                centro.setNombre(resultado.getString("nombre"));
                centro.setCalle(resultado.getString("calle"));
                centro.setNumero(resultado.getString("numero"));               
                centro.setCp(resultado.getString("cp"));
                centro.setCiudad(resultado.getString("ciudad"));
                centro.setProvincia(resultado.getString("ciudad"));
                centro.setTlf(resultado.getString("tlf"));    
                listaCentros.add(centro);
          }
        resultado.close();
        ConexionBD.finalizarConexion();
        return listaCentros;
    }
}
