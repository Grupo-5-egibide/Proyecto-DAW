
package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ViajeBD {
    private static PreparedStatement sentenciaCon;
    private static String plantilla;
    private static Statement sentencia;
    private static ResultSet resultado;
    
    public static void Alta(Viaje v,Parte p) throws Exception{
            ConexionBD.conectarBD();
            plantilla = "INSERT INTO viaje (horaInicio,horaFin,albaran,Partes_idParte) VALUES (?,?,?,?)";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,v.getHoraInicio());
            sentenciaCon.setString(2,v.getHoraFin());
            sentenciaCon.setString(3,v.getAlbaran());
            sentenciaCon.setInt(4,p.getIdParte());
            
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion();
    }
    public static void Baja(Viaje v) throws Exception{
           ConexionBD.conectarBD();
            plantilla = "DELETE FROM `viaje` WHERE albaran = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,v.getAlbaran());
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion(); 
    }
}
