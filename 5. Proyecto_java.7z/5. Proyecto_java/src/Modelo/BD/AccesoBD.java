
package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AccesoBD {
    private static String plantilla;
    private static PreparedStatement sentenciaCon;
    private static ResultSet resultado;
    
    private static Acceso accesoTrabajador;
    
   
    public static Acceso busquedaUsuario(Acceso a) throws Exception{
        ConexionBD.conectarBD();
        
        plantilla = "select idUsuario from acceso where usuario = ? and pass = ?;";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        sentenciaCon.setString(1,a.getUsuario());
        sentenciaCon.setString(2,a.getPass());
            resultado = sentenciaCon.executeQuery();
          if (resultado.next())
          {
                a.setIdAcceso(resultado.getInt("idUsuario"));
          }
        resultado.close();
        ConexionBD.finalizarConexion();
        
        return a;    
    }
    
}
