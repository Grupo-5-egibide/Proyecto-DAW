
package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class VehiculoBD {
    private static PreparedStatement sentenciaCon;
    private static String plantilla;
    private static Statement sentencia;
    private static ResultSet resultado;
    
    public static Vehiculo busquedaIdMatricula(Vehiculo v) throws Exception{
 
        ConexionBD.conectarBD();
        
        plantilla = "select * from vehiculo where matricula = ?;";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        sentenciaCon.setString(1,v.getMatricula());
        resultado = sentenciaCon.executeQuery();
           if (resultado.next())
          {
                v = new Vehiculo();
                v.setIdVehiculo(resultado.getInt("idVehiculo"));
          }
           else{
               v = null;
           }
        resultado.close();     
        ConexionBD.finalizarConexion();

        return v;
    }
}
