
package Modelo.BD;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {
    
    private static Connection con;
    
    public static void conectarBD() throws Exception{
        Class.forName("com.mysql.jdbc.Driver");
        String url="jdbc:mysql://localhost:3307/"+"bdproyecto";
        String user="root";
        String pass="usbw";
        con = DriverManager.getConnection(url, user, pass);
     }
    public static void finalizarConexion() throws Exception{
        con.close();
    }
    public static Connection getCon() {
        return con;
    }
    
    
    
}
