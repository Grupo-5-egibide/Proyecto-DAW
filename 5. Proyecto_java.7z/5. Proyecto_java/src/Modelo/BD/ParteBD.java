package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ParteBD {
    private static PreparedStatement sentenciaCon;
    private static String plantilla;
    private static ResultSet resultado;
    private static Parte p;
    private static Parte parte;
    
    public static Parte buscarParte(Trabajador t,Parte p) throws Exception{
        ConexionBD.conectarBD();
        
        plantilla = "select * from parte where Trabajadores_idTrabajador = ? and estado = 'abierto'";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        sentenciaCon.setInt(1,t.getIdTrabajador());
        resultado = sentenciaCon.executeQuery();
            if (!resultado.next())
            {
               p = null;  
            }
            else
            {
                p.setIdParte(resultado.getInt("idParte"));
                p.setKmInicio(resultado.getInt("kmInicio"));
                p.setKmFin(resultado.getInt("kmFin"));
                p.setGasto(resultado.getDouble("gasto"));
                p.setIncidencia(resultado.getString("incidencia"));
                p.setEstado(resultado.getString("estado"));
                
          }  
        resultado.close();     
        ConexionBD.finalizarConexion();
        return p;
    }
    public static void AltaNuevoParte(Trabajador t,Vehiculo v) throws Exception{
            ConexionBD.conectarBD();
            plantilla = "INSERT INTO parte (estado,Trabajadores_idTrabajador,Vehiculo_idVehiculo) VALUES (?,?,?)";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,"abierto");
            sentenciaCon.setInt(2,t.getIdTrabajador());
            sentenciaCon.setInt(3,v.getIdVehiculo());
            
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion();
    }
    public static ArrayList<Parte> obtenerPartes() throws Exception{
  
        ArrayList<Parte> listaPartes = new ArrayList();
            
        ConexionBD.conectarBD();
        plantilla = "select * from parte";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        resultado = sentenciaCon.executeQuery();
          while (resultado.next())
          {
                parte = new Parte();
                parte.setIdParte(resultado.getInt("idParte"));
                parte.setKmInicio(resultado.getInt("kmInicio"));
                parte.setKmFin(resultado.getInt("kmFin"));
                parte.setGasto(resultado.getDouble("gasto"));
                parte.setIncidencia(resultado.getString("incidencia"));
                parte.setEstado(resultado.getString("estado"));
                listaPartes.add(parte);
          }
        resultado.close();
        ConexionBD.finalizarConexion();
        return listaPartes;
    }
}
