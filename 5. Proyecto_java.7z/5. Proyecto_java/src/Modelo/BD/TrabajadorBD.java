
package Modelo.BD;

import Modelo.UML.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class TrabajadorBD {
    
    private static PreparedStatement sentenciaCon;
    private static String plantilla;
    private static Statement sentencia;
    private static ResultSet resultado;
    
    private static Centro centro;
    private static Trabajador trabajador;
    private static Acceso acceso;
    private static Trabajador categoriaTrabajador;

    
    
     
    public static void altaTrabajador(Trabajador t) throws Exception{
            ConexionBD.conectarBD();
            
//vamos a hacer una consulta a la base de datos para encontrar el id de centro,asi sabremos que id le correspondera al trabajador en funcion 
//del centro que haya escogido en el ComboBox
            plantilla = "select idCentro from centro where nombre = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getCentro().getNombre());
            resultado = sentenciaCon.executeQuery();
            if (resultado.next())
            {
                
                t.getCentro().setIdCentro(resultado.getInt("idCentro"));
            }
            else
                    t =  null;
            
            resultado.close();
        
            
            plantilla = "INSERT INTO acceso (usuario,pass) VALUES (?,?)";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getAcceso().getUsuario());
            sentenciaCon.setString(2,t.getAcceso().getPass());
            
            sentenciaCon.executeUpdate();
            
//hacemos una consulta a la base de datos para encontrar el id del acceso asignado al trabajador, que introduciremos despues
            plantilla = "select idUsuario from acceso where usuario = ? and pass = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getAcceso().getUsuario());
            sentenciaCon.setString(2,t.getAcceso().getPass());
            resultado = sentenciaCon.executeQuery();
            if (resultado.next())
            {
                t.getAcceso().setIdAcceso(resultado.getInt("idUsuario"));
            }
            else
                t =  null;
            
            resultado.close();
            
            
            plantilla = "INSERT INTO trabajador (dni,nombre,ape1,ape2,dir,tlfpers,tlfempr,salario,fnac,categoria,Accesos_idUsuario,Centros_idCentro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getDni());
            sentenciaCon.setString(2,t.getNombre());
            sentenciaCon.setString(3,t.getApellido1());
            sentenciaCon.setString(4,t.getApellido2());
            sentenciaCon.setString(5,t.getDireccion());
            sentenciaCon.setString(6,t.getTelefonoPers());
            sentenciaCon.setString(7,t.getTelefonoEmp());
            sentenciaCon.setString(8,t.getSalario());
            sentenciaCon.setString(9,t.getFechaNacimiento());
            sentenciaCon.setString(10,t.getCategoria());
            sentenciaCon.setInt(11,t.getAcceso().getIdAcceso());
            sentenciaCon.setInt(12,t.getCentro().getIdCentro());
            
            sentenciaCon.executeUpdate();
    
            
            ConexionBD.finalizarConexion();
    } 
    public static void BajaTrabajador(Trabajador t) throws Exception {
       ConexionBD.conectarBD();
            plantilla = "DELETE FROM `trabajador` WHERE dni = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getDni());
            sentenciaCon.executeUpdate();
            
            ConexionBD.finalizarConexion(); 
    }
    public static Trabajador busquedaPorDni(Trabajador t) throws Exception{
            ConexionBD.conectarBD();
            
            plantilla = "select * from trabajador where dni = ?;";
            sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getDni());
            resultado = sentenciaCon.executeQuery();
            if (resultado.next())
            {
                trabajador = new Trabajador();
                trabajador.setDni(resultado.getString("dni"));
                trabajador.setNombre(resultado.getString("nombre"));
                trabajador.setApellido1(resultado.getString("ape1"));
                trabajador.setApellido2(resultado.getString("ape2"));
                trabajador.setDireccion(resultado.getString("dir"));
                trabajador.setTelefonoPers(resultado.getString("tlfpers"));
                trabajador.setTelefonoEmp(resultado.getString("tlfempr"));
                trabajador.setSalario(resultado.getString("salario"));
                trabajador.setFechaNacimiento(resultado.getString("fnac"));
                trabajador.setCategoria(resultado.getString("categoria"));
            }
            else
                trabajador =  null;
            
            resultado.close();
            ConexionBD.finalizarConexion();
            return trabajador;
    }

    //Login
    public static Trabajador busquedaTrabajador(Acceso a) throws Exception{
        //Ahora vamos a buscar los datos del trabajador correspondientes a ese id de usuario, de esta manera tambien podremos encontrar a que
        //CATEGORIA pertence y asi poder darle acceso a un menu u otro
        ConexionBD.conectarBD();
        
        plantilla = "select * from trabajador where Accesos_idUsuario = ?;";
        sentenciaCon = ConexionBD.getCon().prepareStatement(plantilla);
        sentenciaCon.setInt(1,a.getIdAcceso());
        resultado = sentenciaCon.executeQuery();
           if (resultado.next());
          {
                trabajador = new Trabajador();
                trabajador.setIdTrabajador(resultado.getInt("idTrabajador"));
                trabajador.setNombre(resultado.getString("nombre"));
                trabajador.setCategoria(resultado.getString("categoria"));
          }
        resultado.close();     
        ConexionBD.finalizarConexion();

        return trabajador;
    }
            
}
