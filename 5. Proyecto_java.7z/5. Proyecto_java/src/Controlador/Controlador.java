
package Controlador;

import GUI.*;
import Modelo.BD.*;
import Modelo.UML.*;
import Parsers.Aplicacion;
import Parsers.DOMParserAplicacion;
import java.util.ArrayList;

/*
@author Jon, Adrián y Aroa
*/

public class Controlador {
        //Creacion de objetos ventana
        private static ventanaInicialFondo vif;
        private static ventanaLogin vl;
        private static menuAdministracion mAdmin;
        private static menuLogistica mLogis;
        private static ventanaCentros vCen;
        private static ventanaTrabajadores vTrab;
        private static ventanaParte vParte;
        private static ventanaViajes vViajes;
        
        //Relaciones
        private static AccesoBD abd;
        private static CentroBD cenbd;
        private static TrabajadorBD trabd;
        private static ParteBD partebd;
        private static VehiculoBD vehibd;
        private static ViajeBD viajebd;
        
        //Objetos
        public static Trabajador t;
        public static Parte p;
        
        private static Centro centro;
        private static Trabajador trabajador;
        private static Parte parte;
        private static ArrayList<Centro>listaCentros;
        private static ArrayList<Parte>listaPartes;
        
    public static void main(String[] args) {
        vif = new ventanaInicialFondo();
        vif.setVisible(true);
        vl = new ventanaLogin(vif,true);
        vl.setVisible(true);
    }
 
    public static void finalizarPrograma(){
        System.exit(0);
    }
    public static void cerrarSesion(){
        mAdmin.dispose();
        vif = new ventanaInicialFondo();
        vif.setVisible(true);
        vl = new ventanaLogin(vif,true);
        vl.setVisible(true);  
    }
    public static void cerrarVentana(javax.swing.JFrame ventana){
         ventana.dispose();
    }
    
    
    //Login
    public static void buscarUsuario(String usu, String cont) throws Exception{
        Acceso a = new Acceso(usu,cont);
        a=abd.busquedaUsuario(a);  
        
        if(a.getIdAcceso()!=0){
            try{
                busquedaTrabajador(a);
            }
            catch(Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "error - buscar usuario " +e.getMessage());
            }
        }
        else{
            javax.swing.JOptionPane.showMessageDialog(null,"Usuario o contraseña incorrecta");
        }
        
    }
    public static void busquedaTrabajador(Acceso a) throws Exception{
        t=trabd.busquedaTrabajador(a);
        
        if("Administración".equals(t.getCategoria())){
        abrirMenuAdministracion();
        }
        else{
            try{
                comprobarParte();
            }
            catch(Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "error - busqueda trabajador " +e.getMessage());
            }
        }
    }
    public static void getNombreTrabajadorVentana(){
          javax.swing.JOptionPane.showMessageDialog(null,"Bienvenido " +t.getNombre());
    }
    public static String getNombreTrabajadorMenu(Trabajador t){
          return t.getNombre();
    }
    public static void abrirMenuAdministracion(){
        vif.dispose();
        mAdmin=new menuAdministracion();
        mAdmin.setVisible(true);  
    }
    
    
    //Parte
    public static void altaParte(String tfKmInicio,String tfKmFin,String tfGasoil,String tfAutopistas,String tfDietas,String taIncidencia) throws Exception {
        
    }
    public static void comprobarParte() throws Exception{ 
        
        /*primero vamos a buscar si el trabajador de logistica que acaba de acceder al sistema tiene algun parte abierto
        para ello haremos una busqueda en la tabla partes con el id del trabajador, si no hay partes abiertos generaremos uno despues
        en cambio si los hay abriremos los viajes pertenecientes a ese parte*/        
        vif.dispose();
        mLogis=new menuLogistica();
        mLogis.setVisible(true);
        p = new Parte();
        try{
            p = partebd.buscarParte(t,p);
        
            if(p == null){
                String matricula = javax.swing.JOptionPane.showInputDialog(null, "Introduce la matricula del vehiculo con el que se realizará el parte: ");
                Vehiculo v = new Vehiculo(matricula);
                    try{
                        v = vehibd.busquedaIdMatricula(v);
                    }
                    catch(Exception e){
                        javax.swing.JOptionPane.showMessageDialog(null, "error - Busqueda id Matricula " +e.getMessage());
                    }
                //almacenamos el id del Vehiculo y del trabajador para generar el nuevo parte
                partebd.AltaNuevoParte(t,v);
                
                //recogemos los datos del nuevo parte creado
                p = new Parte();
                p = partebd.buscarParte(t,p);
                
                //ahora mostramos la ventana viajes
                vViajes = new ventanaViajes();
                vViajes.setVisible(true);
                
            }
            else{
                //aqui llamaria a los viajes del parte
                vViajes=new ventanaViajes();
                vViajes.setVisible(true);  
            }
        }
        catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "error - comprobar parte " +e.getMessage());
        }
    }
    public static void buscarParte(String operacion) throws Exception {   
       vParte = new ventanaParte(operacion);
       vParte.setVisible(true);
    }
   
    
    //COMPLETAR DATOS PARTE VENTANA
    public static String getIdParte() throws Exception{
        return p.getIdParte().toString();
    }
    public static String getEstadoParte() throws Exception{
        return p.getEstado();
    }


//Parte PARSERS
    public static void obtenerPartes() throws Exception{
         listaPartes = partebd.obtenerPartes();
         for(int x = 0; x < listaPartes.size(); x++);         
    }
    public static void generarParte() throws Exception {
        DOMParserAplicacion.ejecutar();
    }
    
    
    //Viajes
    public static void altaViaje(String hInicio, String hFin, String Alb) throws Exception{
        Viaje v = new Viaje(hInicio,hFin,Alb);
        viajebd.Alta(v,p);
    }
    public static void bajaViaje(String hInicio, String hFin, String Alb) throws Exception{
        Viaje v = new Viaje(hInicio,hFin,Alb);
        ViajeBD.Baja(v);
    }
    
    
    //Centro
    public static void abrirCentro(){
        vCen = new ventanaCentros();
        vCen.setVisible(true);
    }
    public static void altaCentro(String nombre,String calle,String numero,String cp,String ciudad,String provincia,String telefono) throws Exception{
        Centro c = new Centro(nombre,calle,numero,cp,ciudad,provincia,telefono);
        cenbd.Alta(c);
    }
    public static void bajaCentro(String nombre) throws Exception{
        Centro c = new Centro(nombre);
        cenbd.Baja(c);
    }
    public static void modificarCentro(String nombre,String Calle,String Numero,String Cp,String Ciudad,String Provincia,String Telefono) throws Exception{
        Centro c = new Centro(nombre,Calle,Numero,Cp,Ciudad,Provincia,Telefono);
        cenbd.Modificar(c);
    }
    public static void buscarCentro(String nombre,String operacion) throws Exception{
       centro = new Centro(nombre);
       centro = CentroBD.busquedaPorNombre(centro);
       if (centro == null)
           throw new NullPointerException();
       vCen = new ventanaCentros(operacion);
       vCen.setVisible(true);
        
    }
    public static void obtenerCentros(javax.swing.JComboBox cb) throws Exception{
         listaCentros = cenbd.obtenerCentros();
         for(int x = 0; x < listaCentros.size(); x++)
            cb.insertItemAt(listaCentros.get(x).getNombre(),x);
    }
    
    public static String getNombre(){
        return centro.getNombre();
    }
    public static String getCalle(){
        return centro.getCalle();
    }
    public static String getNumero(){
        return centro.getNumero();
    }
    public static String getCp(){
        return centro.getCp();
    }
    public static String getCiudad(){
        return centro.getCiudad();
    }
    public static String getProvincia(){
        return centro.getProvincia();
    }
    public static String getTlf(){
        return centro.getTlf();
    }
    
    
    //Trabajador
    public static void abrirTrabajador() throws Exception{
        vTrab = new ventanaTrabajadores();
        vTrab.setVisible(true);
    }
    public static void altaTrabajador(String dni,String nombre,String apellido1, String apellido2, String direccion,String telefonopers,String telefonoemp,String salario,String fechaNac,String categoria,String centroAsignado,String usuario,String contrasena) throws Exception {
        Centro c = new Centro(centroAsignado);
        Acceso a = new Acceso(usuario,contrasena);
        Trabajador t = new Trabajador(dni,nombre,apellido1,apellido2,direccion,telefonopers,telefonoemp,salario,fechaNac,categoria,a,c);
        trabd.altaTrabajador(t);   
    }
    public static void bajaTrabajador(String dni) throws Exception{
        Trabajador t = new Trabajador(dni);
        trabd.BajaTrabajador(t);
    }
    public static void buscarTrabajador(String dni,String operacion) throws Exception{
       trabajador = new Trabajador(dni);
       trabajador = TrabajadorBD.busquedaPorDni(trabajador);
       if (trabajador == null)
           throw new NullPointerException();
       vTrab = new ventanaTrabajadores(operacion);
       vTrab.setVisible(true);
        
    }
    
    public static String getDNI(){
        return trabajador.getDni();
    }
    public static String getNombreT(){
        return trabajador.getNombre();
    }
    public static String getApellido1(){
        return trabajador.getApellido1();
    }
    public static String getApellido2(){
        return trabajador.getApellido2();
    }
    public static String getDireccion(){
        return trabajador.getDireccion();
    }
    public static String getTlfPers(){
        return trabajador.getTelefonoPers();
    }
    public static String getTlfEmp(){
        return trabajador.getTelefonoEmp();
    }
    public static String getSalario(){
        return trabajador.getSalario();
    }
    public static String getFechaNac(){
        return trabajador.getFechaNacimiento();
    }
    public static String getCategoria(){
        return trabajador.getCategoria();
    }

    
}
