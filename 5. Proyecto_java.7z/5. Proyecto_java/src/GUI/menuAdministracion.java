package GUI;

import Controlador.Controlador;
import Modelo.UML.Trabajador;
import java.util.logging.Level;
import java.util.logging.Logger;


public class menuAdministracion extends javax.swing.JFrame {

    
    public menuAdministracion() {
        initComponents();
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH); 
    }
    public menuAdministracion(Trabajador t){
        initComponents();
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH); 
        prueba.setText(Controlador.getNombreTrabajadorMenu(t));
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        prueba = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        mAltaTrabajador = new javax.swing.JMenuItem();
        mModificarTrabajador = new javax.swing.JMenuItem();
        mEliminarTrabajador = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        mAltaCentro = new javax.swing.JMenuItem();
        mModificarCentro = new javax.swing.JMenuItem();
        mEliminarCentro = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setText("Bienvenido");

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setText("Himevico SL");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo.png"))); // NOI18N

        prueba.setText("hola");

        jButton1.setText("Generar informe partes");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jMenu1.setText("Inicio");

        jMenuItem1.setText("Ayuda");
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Acerca de");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Cerrar sesion");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("Salir");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Trabajadores");

        mAltaTrabajador.setText("Alta trabajador");
        mAltaTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mAltaTrabajadorActionPerformed(evt);
            }
        });
        jMenu2.add(mAltaTrabajador);

        mModificarTrabajador.setText("Modificar trabajador");
        mModificarTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mModificarTrabajadorActionPerformed(evt);
            }
        });
        jMenu2.add(mModificarTrabajador);

        mEliminarTrabajador.setText("Eliminar trabajador");
        mEliminarTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mEliminarTrabajadorActionPerformed(evt);
            }
        });
        jMenu2.add(mEliminarTrabajador);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Centros");

        mAltaCentro.setText("Alta centro ");
        mAltaCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mAltaCentroActionPerformed(evt);
            }
        });
        jMenu3.add(mAltaCentro);

        mModificarCentro.setText("Modificar centro");
        mModificarCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mModificarCentroActionPerformed(evt);
            }
        });
        jMenu3.add(mModificarCentro);

        mEliminarCentro.setText("Eliminar centro");
        mEliminarCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mEliminarCentroActionPerformed(evt);
            }
        });
        jMenu3.add(mEliminarCentro);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3)
                        .addGap(44, 44, 44)
                        .addComponent(prueba, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(289, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jLabel1)
                        .addGap(29, 29, 29)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(prueba, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
       Controlador.finalizarPrograma();
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
       Controlador.cerrarSesion();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void mAltaTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mAltaTrabajadorActionPerformed
        try {
            Controlador.abrirTrabajador();
        } catch (Exception ex) {
            Logger.getLogger(menuAdministracion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mAltaTrabajadorActionPerformed

    private void mAltaCentroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mAltaCentroActionPerformed
       Controlador.abrirCentro();
    }//GEN-LAST:event_mAltaCentroActionPerformed

    private void mModificarTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mModificarTrabajadorActionPerformed
        String dni = javax.swing.JOptionPane.showInputDialog("Introduzca el DNI del trabajador que desea modificar");
        try {
            Controlador.buscarTrabajador(dni,"modificar");
        } 
        catch(NullPointerException e)
        {
           javax.swing.JOptionPane.showMessageDialog(this,"No se puede modificar un trabajador que no existe");
        }
        catch(Exception e)
        {
           javax.swing.JOptionPane.showMessageDialog(this,"Problemas con la modificación" + e.getMessage());
        }                    
    }//GEN-LAST:event_mModificarTrabajadorActionPerformed

    private void mModificarCentroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mModificarCentroActionPerformed
            try{
            String nombre = javax.swing.JOptionPane.showInputDialog(this,"Teclee correctamente el nombre del centro a modificar");
            Controlador.buscarCentro(nombre,"modificar");   
       }
       catch(NullPointerException e)
       {
           javax.swing.JOptionPane.showMessageDialog(this,"No se puede modificar un centro que no existe");
       }
       catch(Exception e)
       {
           javax.swing.JOptionPane.showMessageDialog(this,"Problemas con la modificación" + e.getMessage());
       }                    
    }//GEN-LAST:event_mModificarCentroActionPerformed

    private void mEliminarCentroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mEliminarCentroActionPerformed
       try{
            String nombre = javax.swing.JOptionPane.showInputDialog(this,"Teclee correctamente el nombre del centro a eliminar");
            Controlador.buscarCentro(nombre,"eliminar");   
       }
       catch(NullPointerException e)
       {
           javax.swing.JOptionPane.showMessageDialog(this,"No se puede eliminar un centro que no existe");
       }
       catch(Exception e)
       {
           javax.swing.JOptionPane.showMessageDialog(this,"Problemas con la eliminación" + e.getMessage());
       }                    
    }//GEN-LAST:event_mEliminarCentroActionPerformed

    private void mEliminarTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mEliminarTrabajadorActionPerformed
        String dni = javax.swing.JOptionPane.showInputDialog("Introduzca el DNI del trabajador a eliminar");
       try {
            Controlador.buscarTrabajador(dni,"eliminar");
        } 
       catch(NullPointerException e)
       {
           javax.swing.JOptionPane.showMessageDialog(this,"No se puede eliminar un trabajador que no existe");
       }
       catch(Exception e)
       {
            javax.swing.JOptionPane.showMessageDialog(this,"Problemas con la eliminación" + e.getMessage());
       }                    
    }//GEN-LAST:event_mEliminarTrabajadorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            Controlador.generarParte();
        }
        catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null,"error al generar el informe " +e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuAdministracion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuAdministracion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuAdministracion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuAdministracion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuAdministracion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem mAltaCentro;
    private javax.swing.JMenuItem mAltaTrabajador;
    private javax.swing.JMenuItem mEliminarCentro;
    private javax.swing.JMenuItem mEliminarTrabajador;
    private javax.swing.JMenuItem mModificarCentro;
    private javax.swing.JMenuItem mModificarTrabajador;
    private javax.swing.JLabel prueba;
    // End of variables declaration//GEN-END:variables
}
