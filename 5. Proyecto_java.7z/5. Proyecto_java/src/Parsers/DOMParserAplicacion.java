/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parsers;


import Controlador.Controlador;
import Modelo.UML.Parte;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;
/**
 *
 * @author Aroa
 */
public class DOMParserAplicacion {
    //No generics
    
    private List partes;
    
    private Document dom;
      Element rootElement;
    public DOMParserAplicacion() {
        //create a list to hold the notice objects
        partes = new ArrayList();    
    }
    
    public static void ejecutar() throws ParseException, Exception{
        //runExample();
    }
    public void runExample() throws ParseException, Exception {
        //create an instance
        DOMParserAplicacion dpe = new DOMParserAplicacion();
        
        //call run example
        dpe.runExample();
        
        Controlador.obtenerPartes();
        
        
        //parse the xml file and get the dom object
        creardocxml();

        //get each notice element and create a Noticia object
        parseDocument();

        //Iterate through the list and print the data
        printToFile();
    }

    private void creardocxml() {
        try {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                dom = docBuilder.newDocument();
		rootElement= dom.createElement("listapartes");
		dom.appendChild(rootElement);
            } catch (ParserConfigurationException pce) {
		pce.printStackTrace();
            }
    }
     private void createDOMTree() {   
        Iterator it = partes.iterator();
        while (it.hasNext()) {
            Parte c = (Parte) it.next();
            //For each Contact object  create <contacto> element and attach it to root
           
            rootElement.appendChild(createParteElement(c));
        }
    }
     private Element createParteElement(Parte c) {
        String textoAuxiliar;
        Text nombreText;
        Element Parte = dom.createElement("parte");
        
        //create nombre element and nombre text node and attach it to contactElement
        Element idParte = dom.createElement("idParte");
        textoAuxiliar= String.valueOf(c.getIdParte());
        nombreText = dom.createTextNode(textoAuxiliar);
        idParte.appendChild(nombreText);
        Parte.appendChild(idParte);

        //create apellidos element and apellidos text node and attach it to contactElement
        Element kmInicio = dom.createElement("kmInicio");
        textoAuxiliar= String.valueOf(c.getKmInicio());
        nombreText = dom.createTextNode(textoAuxiliar);
        kmInicio.appendChild(nombreText);
        Parte.appendChild(kmInicio);
        
        //create nombre element and nombre text node and attach it to contactElement
        Element kmFin = dom.createElement("kmFin");
        textoAuxiliar= String.valueOf(c.getIdParte());
        nombreText = dom.createTextNode(textoAuxiliar);
        kmFin.appendChild(nombreText);
        Parte.appendChild(kmFin);
        
        //create nombre element and nombre text node and attach it to contactElement
        Element gasto = dom.createElement("gasto");
        textoAuxiliar= String.valueOf(c.getIdParte());
        nombreText = dom.createTextNode(textoAuxiliar);
        gasto.appendChild(nombreText);
        Parte.appendChild(gasto);
        
        //create nombre element and nombre text node and attach it to contactElement
        Element incidencia = dom.createElement("incidencia");
        textoAuxiliar= String.valueOf(c.getIdParte());
        nombreText = dom.createTextNode(textoAuxiliar);
        incidencia.appendChild(nombreText);
        Parte.appendChild(incidencia);
        
        //create nombre element and nombre text node and attach it to contactElement
        Element estado = dom.createElement("estado");
        textoAuxiliar= String.valueOf(c.getEstado());
        nombreText = dom.createTextNode(textoAuxiliar);
        estado.appendChild(nombreText);
        Parte.appendChild(estado);
      
        return Parte;
    }

    private void parseDocument() throws ParseException {
        //get the root elememt
        Element docEle = dom.getDocumentElement();

        //get a nodelist of <noticia> elements
        NodeList nl = docEle.getElementsByTagName("partes");
        if (nl != null && nl.getLength() > 0) {
            for (int i = 0; i < nl.getLength(); i++) {

                //get the libro element
                Element el = (Element) nl.item(i);

                //get the parte object
                Parte p = getParte (el);

                //add it to list 
                partes.add (p); 
            }
        }
    }

    /**
     * I take an notice element and read the values in, create an Noticia
     * object and return it
     *
     * @param notEl
     * @return
     */
   
   private Parte getParte(Element notEl) throws ParseException {       
           int idParte = Integer.parseInt(notEl.getAttribute("id"));        
           int kmIni = Integer.parseInt(getTextValue(notEl, "km Inicio"));
           int kmFin = Integer.parseInt(getTextValue(notEl, "km Fin"));
           double gasto = Double.parseDouble(getTextValue(notEl, "gasto"));
           String incidencia = getTextValue(notEl, "incidencias");
           String estado = getTextValue(notEl, "estado");
           
           
           Parte p = new Parte (idParte, kmIni, kmFin, gasto, incidencia, estado);
           return p;
    }

    
    /**
     * I take a xml element and the tag name, look for the tag and get the text
     * content i.e for <item><title>John....</title><item> xml snippet if the
     * Element points to notice node and tagName is title I will return John
     *
     * @param ele
     * @param tagName
     * @return
     */
    private String getTextValue(Element ele, String tagName) {
        String textVal = null;

        NodeList nl = ele.getElementsByTagName(tagName);
        if (nl != null && nl.getLength() > 0) {
            Element el = (Element) nl.item(0);
            textVal = el.getFirstChild().getNodeValue();
           
        }
        return textVal;
    }

    /**
     * Iterate through the list and print the content to console
     */
    /*private void printData() {
       
        System.out.println("Número de partes " + partes.size());        
        System.out.println("\nDetalles del parte\n");        
        System.out.println("\n------------------------------------------------");
        Iterator it = partes.iterator();
        while (it.hasNext()) {
            System.out.println(it.next().toString());
        } 
        }*/
    
    private void printToFile() {

        try {
            //print
            OutputFormat format = new OutputFormat(dom);
            format.setIndenting(true);

            //to generate output to console use this serializer
            //XMLSerializer serializer = new XMLSerializer(System.out, format);

            //to generate a file output use fileoutputstream instead of system.out
            XMLSerializer serializer = new XMLSerializer(
                    new FileOutputStream(new File("partes.xml")), format);

            serializer.serialize(dom);

        } catch (IOException ie) {
            ie.printStackTrace();
        }
        
        
        }
    
        
public static void XMLtoHTML(){
  try {

    TransformerFactory tFactory = TransformerFactory.newInstance();

    Transformer transformer =   tFactory.newTransformer    (new javax.xml.transform.stream.StreamSource("partes.xsl"));

    transformer.transform (new javax.xml.transform.stream.StreamSource ("partes.xml"), new javax.xml.transform.stream.StreamResult( new FileOutputStream("partes.html")));
    }
  catch (Exception e) {
    e.printStackTrace( );
    }
  }
}
    
    

      

