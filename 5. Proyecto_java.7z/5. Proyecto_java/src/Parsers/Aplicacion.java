package Parsers;


import java.io.IOException;
import java.text.ParseException;

/**
 *
 * @author user
 */
public class Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException, Exception {
        // TODO code application logic here
        System.out.println("DOM");
        System.out.println("---");

        //create an instance
        DOMParserAplicacion dpe = new DOMParserAplicacion();
        
        //call run example
        dpe.runExample();
    
    }
    
}
